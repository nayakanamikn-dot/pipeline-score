/**
 * Pipeline Score — Question Data
 * Each question has a category, text, and scored options.
 * Total max score: 100 (10 questions × max 10 points each)
 */

const QUESTIONS = [
  {
    category: "LinkedIn Presence",
    text: "How often are you posting on LinkedIn right now?",
    options: [
      { label: "Daily or 4-5x per week consistently", score: 10 },
      { label: "2-3x per week but sometimes I skip weeks", score: 7 },
      { label: "A few times a month when I remember", score: 4 },
      { label: "Rarely or never", score: 1 }
    ]
  },
  {
    category: "LinkedIn Presence",
    text: "Are you getting inbound DMs or inquiries from your LinkedIn content?",
    options: [
      { label: "Yes, regularly — multiple per week", score: 10 },
      { label: "Occasionally — a few per month", score: 7 },
      { label: "Rarely — maybe one every few months", score: 3 },
      { label: "Never", score: 1 }
    ]
  },
  {
    category: "Cold Outreach",
    text: "Do you have a cold email or outbound system running right now?",
    options: [
      { label: "Yes — automated sequences sending daily with good deliverability", score: 10 },
      { label: "Yes but it's inconsistent or deliverability is bad", score: 6 },
      { label: "Tried it before but stopped", score: 3 },
      { label: "No outbound system at all", score: 1 }
    ]
  },
  {
    category: "Cold Outreach",
    text: "How many outbound touches (emails, DMs, calls) are you making per week?",
    options: [
      { label: "200+ per week across channels", score: 10 },
      { label: "50-200 per week", score: 7 },
      { label: "Under 50 per week", score: 4 },
      { label: "Almost zero — I rely on inbound and referrals", score: 1 }
    ]
  },
  {
    category: "CRM & Follow-up",
    text: "Do you have a CRM tracking every lead and follow-up?",
    options: [
      { label: "Yes — every lead is tagged, scored, and has automated follow-up", score: 10 },
      { label: "Yes but it's messy — lots of leads with no follow-up", score: 5 },
      { label: "I use spreadsheets or notes to track leads", score: 3 },
      { label: "No system — leads live in my inbox and memory", score: 1 }
    ]
  },
  {
    category: "CRM & Follow-up",
    text: "When a lead goes cold, what happens?",
    options: [
      { label: "Automated nurture sequence kicks in and re-engages them", score: 10 },
      { label: "I manually follow up when I remember", score: 5 },
      { label: "They usually fall through the cracks", score: 2 },
      { label: "Nothing — once they go cold, they're gone", score: 1 }
    ]
  },
  {
    category: "Content System",
    text: "Do you have a repeatable content creation system?",
    options: [
      { label: "Yes — batched, scheduled, templated, and someone helps me", score: 10 },
      { label: "I batch sometimes but it's mostly ad hoc", score: 6 },
      { label: "I write each post from scratch when inspiration strikes", score: 3 },
      { label: "I don't create content regularly", score: 1 }
    ]
  },
  {
    category: "Content System",
    text: "Is your content driving measurable results (calls booked, leads, revenue)?",
    options: [
      { label: "Yes — I can attribute leads and revenue to specific content", score: 10 },
      { label: "I think it helps but I can't prove it with data", score: 5 },
      { label: "It gets engagement but no clear business impact", score: 3 },
      { label: "No idea — I don't track it", score: 1 }
    ]
  },
  {
    category: "Pipeline Predictability",
    text: "How predictable is your pipeline right now?",
    options: [
      { label: "Very — I know roughly how many leads and calls I'll get each month", score: 10 },
      { label: "Somewhat — good months and bad months, can't control it", score: 5 },
      { label: "Unpredictable — feast or famine", score: 3 },
      { label: "I have no pipeline — business comes from luck and referrals", score: 1 }
    ]
  },
  {
    category: "Pipeline Predictability",
    text: "If you stopped all marketing activity today, how long before your pipeline dries up?",
    options: [
      { label: "3+ months — systems keep running without me", score: 10 },
      { label: "1-2 months — some things are automated", score: 7 },
      { label: "2-4 weeks — most things depend on me personally", score: 4 },
      { label: "Immediately — everything stops when I stop", score: 1 }
    ]
  }
];

const CATEGORY_MAP = {
  "LinkedIn Presence":      { indices: [0, 1], max: 20 },
  "Cold Outreach":          { indices: [2, 3], max: 20 },
  "CRM & Follow-up":       { indices: [4, 5], max: 20 },
  "Content System":         { indices: [6, 7], max: 20 },
  "Pipeline Predictability": { indices: [8, 9], max: 20 }
};

const RECOMMENDATIONS = {
  "LinkedIn Presence": {
    title: "Systematize your LinkedIn content",
    desc: "You have traction potential but no system. A ghostwritten content engine with daily engagement and DM sequences would turn your profile into a consistent lead source."
  },
  "Cold Outreach": {
    title: "Build a cold outreach machine",
    desc: "Without outbound, you're leaving 60-70% of your addressable market untouched. A warmed email infrastructure with targeted sequences can generate 10+ qualified conversations per month."
  },
  "CRM & Follow-up": {
    title: "Fix your lead follow-up system",
    desc: "You're generating interest but losing leads in the gaps. A properly configured CRM with automated nurture sequences can recover 30-40% of leads that currently go cold."
  },
  "Content System": {
    title: "Build a repeatable content engine",
    desc: "Ad hoc content creation burns your time and produces inconsistent results. A batched, templated system with clear content pillars will 3x your output in half the time."
  },
  "Pipeline Predictability": {
    title: "Remove yourself as the bottleneck",
    desc: "Your pipeline dies when you stop working. Automated systems for content, outreach, and follow-up create predictable monthly lead flow that runs without you."
  }
};

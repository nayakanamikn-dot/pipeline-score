/**
 * Pipeline Score — Main Application
 * Production-ready quiz engine with email capture and analytics
 */

(function () {
  'use strict';

  // ── STATE ──
  let currentQuestion = 0;
  let answers = new Array(QUESTIONS.length).fill(null);
  let capturedLead = { name: '', email: '' };

  // ── CONFIG ──
  const CONFIG = {
    calendarUrl: 'mailto:nayak.anamik.n@gmail.com',
    linkedinUrl: 'https://www.linkedin.com/in/anamikanayak',
    maxScore: 100,
    circumference: 2 * Math.PI * 88
  };

  // ── DOM REFS ──
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  const screens = {
    intro: $('#screen-intro'),
    quiz: $('#screen-quiz'),
    capture: $('#screen-capture'),
    results: $('#screen-results')
  };

  // ── SCREEN MANAGEMENT ──
  function showScreen(name) {
    Object.values(screens).forEach(s => s.classList.add('hidden'));
    screens[name].classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    trackEvent('screen_view', { screen: name });
  }

  // ── ANALYTICS HELPER ──
  function trackEvent(event, data = {}) {
    try {
      // Google Analytics 4
      if (typeof gtag === 'function') {
        gtag('event', event, data);
      }
      // Vercel Analytics
      if (typeof window.va === 'function') {
        window.va('event', { name: event, ...data });
      }
      // Console in dev
      if (window.location.hostname === 'localhost') {
        console.log('[Analytics]', event, data);
      }
    } catch (e) {
      // Silently fail — analytics should never break the app
    }
  }

  // ── QUIZ ENGINE ──
  function startQuiz() {
    showScreen('quiz');
    renderQuestion();
    trackEvent('quiz_started');
  }

  function renderQuestion() {
    const q = QUESTIONS[currentQuestion];
    const total = QUESTIONS.length;
    const progress = ((currentQuestion + 1) / total) * 100;

    $('#progress-count').textContent = `${currentQuestion + 1} / ${total}`;
    $('#progress-fill').style.width = `${progress}%`;

    const container = $('#question-container');
    container.innerHTML = `
      <div class="question-card">
        <div class="q-category">${escapeHtml(q.category)}</div>
        <div class="q-text">${escapeHtml(q.text)}</div>
        <div class="options" role="radiogroup" aria-label="${escapeHtml(q.text)}">
          ${q.options.map((opt, i) => `
            <div class="option ${answers[currentQuestion] === i ? 'selected' : ''}"
                 role="radio"
                 aria-checked="${answers[currentQuestion] === i}"
                 tabindex="0"
                 data-index="${i}">
              <div class="option-dot" aria-hidden="true"></div>
              <span>${escapeHtml(opt.label)}</span>
            </div>
          `).join('')}
        </div>
        <div class="q-nav">
          <button class="btn-back" ${currentQuestion === 0 ? 'style="visibility:hidden"' : ''}
                  aria-label="Go to previous question">← Back</button>
          <button class="btn-next ${answers[currentQuestion] !== null ? 'active' : ''}"
                  id="nextBtn"
                  aria-label="${currentQuestion === total - 1 ? 'See your score' : 'Go to next question'}">
            ${currentQuestion === total - 1 ? 'See My Score →' : 'Next →'}
          </button>
        </div>
      </div>
    `;
  }

  function selectOption(idx) {
    answers[currentQuestion] = idx;
    $$('.option').forEach((el, i) => {
      const isSelected = i === idx;
      el.classList.toggle('selected', isSelected);
      el.setAttribute('aria-checked', isSelected);
    });
    $('#nextBtn').classList.add('active');
    trackEvent('option_selected', {
      question: currentQuestion + 1,
      option: idx,
      score: QUESTIONS[currentQuestion].options[idx].score
    });
  }

  function goBack() {
    if (currentQuestion > 0) {
      currentQuestion--;
      renderQuestion();
    }
  }

  function goNext() {
    if (answers[currentQuestion] === null) return;
    if (currentQuestion < QUESTIONS.length - 1) {
      currentQuestion++;
      renderQuestion();
    } else {
      showCaptureScreen();
    }
  }

  // ── EMAIL CAPTURE ──
  function showCaptureScreen() {
    showScreen('capture');
    trackEvent('capture_shown');
    // Auto-focus name input
    setTimeout(() => $('#capture-name')?.focus(), 300);
  }

  function validateAndReveal() {
    const nameInput = $('#capture-name');
    const emailInput = $('#capture-email');
    const errorEl = $('#capture-error');

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Reset errors
    nameInput.classList.remove('error');
    emailInput.classList.remove('error');
    errorEl.classList.add('hidden');

    let hasError = false;

    if (!name) {
      nameInput.classList.add('error');
      hasError = true;
    }

    if (!email || !emailRegex.test(email)) {
      emailInput.classList.add('error');
      hasError = true;
    }

    if (hasError) {
      errorEl.classList.remove('hidden');
      return;
    }

    capturedLead = { name, email };
    trackEvent('lead_captured', { name, email });

    // Store lead locally (for webhook/CRM integration later)
    storeLead(capturedLead);

    showResults();
  }

  function storeLead(lead) {
    try {
      const leads = JSON.parse(localStorage.getItem('pipeline_leads') || '[]');
      leads.push({
        ...lead,
        timestamp: new Date().toISOString(),
        score: calculateTotalScore()
      });
      localStorage.setItem('pipeline_leads', JSON.stringify(leads));
    } catch (e) {
      // Storage might be unavailable — fail silently
    }
  }

  // ── SCORE CALCULATION ──
  function calculateTotalScore() {
    let total = 0;
    answers.forEach((ansIdx, qIdx) => {
      if (ansIdx !== null) {
        total += QUESTIONS[qIdx].options[ansIdx].score;
      }
    });
    return total;
  }

  function calculateCategoryScores() {
    const scores = {};
    for (const [cat, info] of Object.entries(CATEGORY_MAP)) {
      let catTotal = 0;
      info.indices.forEach(i => {
        if (answers[i] !== null) {
          catTotal += QUESTIONS[i].options[answers[i]].score;
        }
      });
      scores[cat] = Math.round((catTotal / info.max) * 100);
    }
    return scores;
  }

  function getGrade(score) {
    if (score >= 80) return { grade: 'A', color: 'var(--green)', label: 'Strong Pipeline' };
    if (score >= 60) return { grade: 'B', color: 'var(--green)', label: 'Good Foundation' };
    if (score >= 40) return { grade: 'C', color: 'var(--yellow)', label: 'Leaking Pipeline' };
    if (score >= 25) return { grade: 'D', color: 'var(--accent)', label: 'Major Gaps' };
    return { grade: 'F', color: 'var(--red)', label: 'Pipeline Emergency' };
  }

  // ── RESULTS RENDERING ──
  function showResults() {
    showScreen('results');

    const totalScore = calculateTotalScore();
    const catScores = calculateCategoryScores();
    const { grade, color, label } = getGrade(totalScore);
    const offset = CONFIG.circumference - (totalScore / CONFIG.maxScore) * CONFIG.circumference;

    // Build recommendations from weakest categories
    const sortedCats = Object.entries(catScores).sort((a, b) => a[1] - b[1]);
    const recs = sortedCats.slice(0, 3).map(([cat, score], i) => ({
      priority: i === 0 ? 'high' : i === 1 ? 'medium' : 'low',
      priorityLabel: i === 0 ? 'Fix First' : i === 1 ? 'Fix Next' : 'Optimize',
      cat,
      score,
      ...RECOMMENDATIONS[cat]
    }));

    const emailSubject = encodeURIComponent(`Pipeline Score: ${totalScore}/100 - Let's Talk`);
    const emailBody = encodeURIComponent(
      `Hi Anamika,\n\nMy pipeline score was ${totalScore}/100.\n\nName: ${capturedLead.name}\nEmail: ${capturedLead.email}\n\nWeakest areas:\n${recs.map(r => `- ${r.cat}: ${r.score}%`).join('\n')}\n\nI'd love to chat about fixing the gaps.\n\nThanks!`
    );

    screens.results.innerHTML = `
      <div class="results-header">
        <h2>${escapeHtml(capturedLead.name)}, here's your Pipeline Score</h2>
        <p>Here's where your lead generation stands today</p>
      </div>

      <div class="score-ring">
        <svg viewBox="0 0 200 200" aria-hidden="true">
          <circle class="ring-bg" cx="100" cy="100" r="88"/>
          <circle class="ring-fill" cx="100" cy="100" r="88"
            stroke-dasharray="${CONFIG.circumference}"
            stroke-dashoffset="${CONFIG.circumference}"
            style="stroke:${color}"
            id="scoreRing"/>
        </svg>
        <div class="score-center">
          <div class="score-number" style="color:${color}" id="scoreNum" aria-label="Score: ${totalScore} out of 100">0</div>
          <div class="score-out-of">/ 100</div>
        </div>
      </div>

      <div style="text-align:center">
        <span class="score-grade" style="color:${color};border:1px solid ${color};background:${color}15">
          Grade ${grade} — ${label}
        </span>
      </div>

      <div class="breakdown">
        <div class="breakdown-title">Category Breakdown</div>
        ${Object.entries(catScores).map(([cat, score]) => {
          const barColor = score >= 70 ? 'var(--green)' : score >= 40 ? 'var(--yellow)' : 'var(--red)';
          return `
            <div class="breakdown-item">
              <div class="breakdown-label">${escapeHtml(cat)}</div>
              <div class="breakdown-bar-wrap">
                <div class="breakdown-bar" style="width:0%;background:${barColor}" data-width="${score}%"></div>
              </div>
              <div class="breakdown-pct" style="color:${barColor}">${score}%</div>
            </div>
          `;
        }).join('')}
      </div>

      <div class="recs">
        <div class="breakdown-title">Your Action Plan</div>
        ${recs.map(r => `
          <div class="rec-card">
            <div class="rec-priority ${r.priority}">${escapeHtml(r.priorityLabel)} — ${escapeHtml(r.cat)} (${r.score}%)</div>
            <div class="rec-title">${escapeHtml(r.title)}</div>
            <div class="rec-desc">${escapeHtml(r.desc)}</div>
          </div>
        `).join('')}
      </div>

      <div class="results-cta">
        <h3>Want me to fix these gaps for you?</h3>
        <p>I build pipeline systems for B2B founders — LinkedIn, cold outreach, CRM automation. Book a free 15-min call and I'll show you exactly how to go from ${totalScore}/100 to 80+.</p>
        <a href="${CONFIG.calendarUrl}?subject=${emailSubject}&body=${emailBody}" class="btn-primary">Book a Free Strategy Call →</a>
        <div class="cta-note">No pitch — just a plan tailored to your score</div>
      </div>

      <div class="share-bar">
        <p>Share your score</p>
        <div class="share-btns">
          <button class="share-btn" data-share="linkedin" aria-label="Share on LinkedIn">LinkedIn</button>
          <button class="share-btn" data-share="twitter" aria-label="Share on Twitter">Twitter / X</button>
          <button class="share-btn" data-share="copy" aria-label="Copy link">Copy Link</button>
        </div>
      </div>

      <div class="powered">
        Built by <a href="${CONFIG.linkedinUrl}" target="_blank" rel="noopener noreferrer">Anamika Nayak</a> — I build pipeline systems for B2B founders
      </div>
    `;

    // Animate after DOM paint
    requestAnimationFrame(() => {
      setTimeout(() => {
        const ring = $('#scoreRing');
        if (ring) ring.style.strokeDashoffset = offset;
        animateNumber('scoreNum', 0, totalScore, 1500);
        $$('.breakdown-bar').forEach(bar => {
          bar.style.width = bar.dataset.width;
        });
      }, 300);
    });

    trackEvent('results_shown', {
      score: totalScore,
      grade,
      weakest_category: recs[0]?.cat
    });
  }

  // ── UTILITIES ──
  function animateNumber(id, start, end, duration) {
    const el = document.getElementById(id);
    if (!el) return;
    const range = end - start;
    const startTime = performance.now();

    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(start + range * eased);
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ── SHARE FUNCTIONS ──
  function shareLinkedIn() {
    const score = calculateTotalScore();
    const url = encodeURIComponent(window.location.href);
    window.open(
      `https://www.linkedin.com/sharing/share-offsite/?url=${url}`,
      '_blank',
      'noopener,noreferrer'
    );
    trackEvent('share_clicked', { platform: 'linkedin', score });
  }

  function shareTwitter() {
    const score = calculateTotalScore();
    const text = encodeURIComponent(
      `Just took the Pipeline Score audit — scored ${score}/100. Shows exactly where your lead gen is leaking in 60 seconds. Worth trying if you're a B2B founder 👇`
    );
    const url = encodeURIComponent(window.location.href);
    window.open(
      `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
      '_blank',
      'noopener,noreferrer'
    );
    trackEvent('share_clicked', { platform: 'twitter', score });
  }

  function copyLink(btn) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(window.location.href).then(() => {
        btn.textContent = 'Copied!';
        setTimeout(() => { btn.textContent = 'Copy Link'; }, 2000);
      }).catch(() => {
        fallbackCopy(btn);
      });
    } else {
      fallbackCopy(btn);
    }
    trackEvent('share_clicked', { platform: 'copy' });
  }

  function fallbackCopy(btn) {
    const input = document.createElement('input');
    input.value = window.location.href;
    document.body.appendChild(input);
    input.select();
    try {
      document.execCommand('copy');
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = 'Copy Link'; }, 2000);
    } catch (e) {
      btn.textContent = 'Failed';
      setTimeout(() => { btn.textContent = 'Copy Link'; }, 2000);
    }
    document.body.removeChild(input);
  }

  // ── EVENT DELEGATION ──
  document.addEventListener('click', function (e) {
    const target = e.target;

    // Start button
    if (target.id === 'btn-start') {
      startQuiz();
      return;
    }

    // Option selection
    const option = target.closest('.option');
    if (option) {
      const idx = parseInt(option.dataset.index, 10);
      if (!isNaN(idx)) selectOption(idx);
      return;
    }

    // Back button
    if (target.classList.contains('btn-back')) {
      goBack();
      return;
    }

    // Next button
    if (target.id === 'nextBtn' || target.closest('#nextBtn')) {
      goNext();
      return;
    }

    // Email capture reveal
    if (target.id === 'btn-reveal' || target.closest('#btn-reveal')) {
      validateAndReveal();
      return;
    }

    // Share buttons
    const shareBtn = target.closest('[data-share]');
    if (shareBtn) {
      const platform = shareBtn.dataset.share;
      if (platform === 'linkedin') shareLinkedIn();
      else if (platform === 'twitter') shareTwitter();
      else if (platform === 'copy') copyLink(shareBtn);
      return;
    }
  });

  // ── KEYBOARD NAVIGATION ──
  document.addEventListener('keydown', function (e) {
    // Enter or Space on options
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('option')) {
      e.preventDefault();
      const idx = parseInt(e.target.dataset.index, 10);
      if (!isNaN(idx)) selectOption(idx);
    }

    // Enter on capture form
    if (e.key === 'Enter' && (e.target.id === 'capture-name' || e.target.id === 'capture-email')) {
      e.preventDefault();
      validateAndReveal();
    }

    // Arrow keys for option navigation
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && e.target.classList.contains('option')) {
      e.preventDefault();
      const options = Array.from($$('.option'));
      const currentIdx = options.indexOf(e.target);
      let nextIdx;
      if (e.key === 'ArrowDown') {
        nextIdx = currentIdx < options.length - 1 ? currentIdx + 1 : 0;
      } else {
        nextIdx = currentIdx > 0 ? currentIdx - 1 : options.length - 1;
      }
      options[nextIdx].focus();
    }
  });

  // ── INITIAL TRACKING ──
  trackEvent('page_loaded');

})();
